# Activity Log

Settings → Activity Log is available on Android in both views and in the Trusted Contact web portal. It combines the signed-in account's Android and web actions. Connected users cannot read each other's activity. Activity starts with this release; existing history is not backfilled.

## Behavior and design

- Inherit DESIGN.md: existing charcoal surfaces, system typography, standard navigation and confirmation dialogs. This is an Operate surface for reviewing and managing account activity, with no new visual system or raster assets.
- Display newest first, grouped by local date, with exact time including seconds, platform, plain-language description and pending-upload state. Android retains its local activity offline; web retains pending events in a dedicated IndexedDB outbox. Cloud availability is explained separately from an empty log.
- Load cloud activity in increments of 50. Category controls explicitly filter loaded entries. Activity Log's own navigation and management actions are excluded, so clearing it leaves it empty.
- Retention is independent of Alert History: manual by default, 1/3/7 days, or custom 1–3,650 whole days. Shortening requires a server-backed count preview and confirmation. Each day is 24 hours from the original activity time.
- Deletion, clearing and retention changes require an online acknowledgement and apply across the account. Deleting activity never deletes alerts, sessions, calibration, profiles, connections or synchronization queues.
- Cleanup runs at authenticated startup, foreground/focus, log entry, policy changes and each visible minute; Android also has hourly WorkManager cleanup. Cloud cleanup removes at most 200 expired documents per pass and resumes on later passes. No exact deletion time is promised while all clients are closed/offline. Longer retention never restores removed entries.

## Contract and event catalogue

Kotlin `ActivityAction` and TypeScript `activityActions` define the same 26 event codes and labels. Events include successful registration/explicit sign-in/logout, profile saves, authenticated screen/detail visits, device connection/disconnection/setup, calibration actions, monitoring start/stop, connection request actions, view/preferences changes, alert-history retention changes and history deletion. Pause/resume codes are reserved for platforms that expose those operations; the current Android monitoring UI does not expose them.

`SCREEN_VIEW` records a safe screen key, never route parameters. Navigation entry is recorded once per actual visit, not per render/recomposition. Operations record actual outcomes; monitoring start also records a request correlated to its outcome by operation ID. Session restoration is not an explicit sign-in. Device connection reflects a connected camera stream, including reconnection; it does not claim a button tap. Interrupted monitoring completion records that monitoring stopped.

Each event contains `eventId`, `schemaVersion=1`, `occurredAt` (client epoch milliseconds), `platform`, `activeView`, `category`, `action`, `outcome`, `detail` (an allowlisted screen key or empty), `operationId`, and cloud `receivedAt` (server timestamp). No typed text, names, phone numbers, emails, connection codes, credentials, media, location, raw detection measurements or exception messages are stored. Device time determines display/order/retention; excessively future-dated uploads are rejected by rules. This is user-manageable history, not a tamper-proof audit trail.

## Persistence and removal

Android Room 5→6 adds UID-scoped `activity_entries` and `activity_policies`, preserving all existing data. A separate WorkManager pipeline uploads stable event IDs; it does not touch Stage 3 synchronization. Logging uses an application coroutine scope and never waits for cloud writes in monitoring operations. Pending logout activity can upload when the same account authenticates again.

The web uses `drivealert-activity-v1` IndexedDB for its UID-scoped outbox. It does not enable general Firestore disk persistence or change existing alert-history storage. Cross-tab notifications refresh pending state. Browser storage failure is surfaced in the Activity Log. Clearing browser data can remove activity that has not uploaded yet.

Under `users/{uid}`, `activityLogs` holds immutable event documents; `activityLogSettings/policy` holds `days`, monotonic `expiredBefore`/`clearedBefore`, `revision` and server `updatedAt`; `activityLogDeletions` holds minimal event-ID deletion markers. Individual deletion writes its marker and removes the payload atomically. Cutoffs handle account-wide clearing/expiry. Removal state is checked during reads, local reconciliation and upload transactions, and enforced by Firestore rules so delayed uploads cannot restore deleted activity. Minimal markers remain to prevent resurrection.

Policy revisions reject stale changes. Concurrent transactions can fail with a permissions/conflict error before retry; clients must refresh and review rather than silently overwrite. Source events are never edited. Rules and indexes must be deployed together with the clients through the project's explicitly authorized release workflow.

## Validation and rollout

Tests cover policy boundaries/validation, safe descriptions, outbox reload and UID isolation, Room migration/expiry/upload state, offline native UI, native emulator synchronization, immutable private Firestore records, monotonic cutoffs/deletion markers, and browser timeline/retention/cross-tab/offline behavior. UI captures belong in output/, not production assets. No production test fixtures are seeded.

Keep Android Studio Iguana/JBR 17 and the pinned Gradle/Kotlin/SDK versions. Use JDK 21+ separately for Firebase emulators. Run Android unit/build/instrumentation checks, web `npm run check`, Firebase rules tests and Playwright emulator tests. No deployment, commit or push is part of these checks.

Verified for this change: Android debug/test APK builds and all 238 JVM tests; all 69 web tests, typecheck, lint and production build; 25 Firebase emulator tests; all 14 browser end-to-end tests, including axe A/AA checks at desktop/mobile widths. The later cross-tab offline refinement also passed its focused browser scenario. The nine focused native migration, activity DAO/UI and cloud synchronization tests pass on the API 35 phone emulator.

A broader native regression run passed 40 of 43 checks. Three existing `PostAuthFlowTest` checks failed: `freshAuthenticationRequiresLiveCalibrationBeforeMonitoring` found that the setup-needed label was not displayed, `driverHomeSeparatesMonitoringToggleFromActivityNavigation` could not open its expected Face mask choice from its fixture, and `everyMonitoringAvailabilityScenarioHasPlainLanguageStatus` could not see its expected status. The latter two exercise unchanged Home/Monitoring screen implementations directly. These failures are recorded in `output/activity-native-results.txt`; those unrelated screens/tests were not changed. Tablet layouts and physical ESP32 behavior were not tested for this feature.

The visual finish review returned **ship** at the incumbent system scope. Documentation review confirmed that DESIGN.md and PRODUCT.md can remain unchanged. No website, Firebase rules or indexes have been deployed, and no commit/push was made.
