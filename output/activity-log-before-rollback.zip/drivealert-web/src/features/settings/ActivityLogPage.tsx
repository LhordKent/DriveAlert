import { useState } from 'react'
import { Link } from 'react-router-dom'
import { ArrowLeft, Trash2 } from 'lucide-react'
import { PageHeader } from '../../components/PageHeader'
import { Button } from '../../components/Button'
import { ConfirmDialog } from '../../components/ConfirmDialog'
import { activityCategories, activityDescription } from '../../models/activity'
import { activityRepository } from '../../repositories/activityRepository'
import { useActivityLog } from './useActivityLog'

export function ActivityLogPage() {
  const log = useActivityLog()
  const [category, setCategory] = useState('ALL')
  const [deleting, setDeleting] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [message, setMessage] = useState<string | null>(null)
  const filtered = log.entries.filter((event) => category === 'ALL' || event.category === category)
  let previousDate = ''
  const remove = async () => {
    if (!log.uid || !deleting) return
    setBusy(true); setError(null)
    try {
      if (deleting === 'ALL') await activityRepository.clear(log.uid)
      else await activityRepository.remove(log.uid, deleting)
      setMessage(deleting === 'ALL' ? 'Activity cleared from your account.' : 'Activity deleted from your account.')
      setDeleting(null); log.refresh()
    } catch { setError('Deletion could not be confirmed. Connect to the internet and try again.') }
    finally { setBusy(false) }
  }
  return <>
    <Link to="/settings" className="mb-5 inline-flex min-h-12 items-center gap-2 text-sm font-semibold text-secondary hover:text-primary"><ArrowLeft className="size-4" aria-hidden="true" />Back to Settings</Link>
    <PageHeader title="Activity Log" description="Your actions across DriveAlert on Android and web. Only you can see this activity." />
    <div className="max-w-3xl space-y-6">
      <div className="flex flex-wrap items-center gap-3">
        <Link to="/settings/activity/retention" className="inline-flex min-h-12 items-center rounded-control border border-border px-4 text-sm font-semibold hover:bg-control">Log retention</Link>
        <Button variant="secondary" onClick={log.refresh}>Refresh activity</Button>
        <Button variant="secondary" disabled={!log.online || busy || !log.entries.length} onClick={() => { setError(null); setDeleting('ALL') }}>Clear all activity</Button>
      </div>
      <p className="text-sm leading-6 text-secondary">{log.policy.days === null ? 'Kept until you delete it.' : `Automatically removed after ${log.policy.days} day${log.policy.days === 1 ? '' : 's'}.`} Deletions apply to your account across devices. Alerts and monitoring records are kept separately.</p>
      {!log.online && <p role="status" className="text-sm leading-6 text-secondary">Cloud history may be unavailable or out of date. Pending activity stays in this browser until it can upload. Connect to change retention or delete entries.</p>}
      {(log.error || error) && <p role="alert" className="text-sm text-signal">{error || log.error}</p>}
      {message && <p role="status" className="text-sm text-secondary">{message}</p>}
      <div><label className="field-label" htmlFor="activity-category">Category</label><select id="activity-category" className="field max-w-xs" value={category} onChange={(event) => setCategory(event.target.value)}>{Object.entries(activityCategories).map(([value, label]) => <option key={value} value={value}>{label}</option>)}</select><p className="mt-2 text-sm text-muted">Filters the activity loaded below. Load more to include earlier entries.</p></div>
      {log.loading && <p role="status" className="text-secondary">Loading activity…</p>}
      {!log.loading && !filtered.length && <div className="surface p-6"><h2 className="section-title">{log.online ? 'No activity to show' : 'No locally available activity'}</h2><p className="mt-2 text-sm leading-6 text-secondary">{category === 'ALL' ? 'Activity appears here as you use DriveAlert. Older activity is not added retroactively.' : 'There are no loaded entries in this category.'}</p></div>}
      <ol className="space-y-1">{filtered.map((event) => {
        const date = new Date(event.occurredAt).toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' })
        const heading = date !== previousDate
        previousDate = date
        return <li key={event.eventId}>{heading && <h2 className="mb-2 mt-6 text-sm font-semibold text-secondary">{date}</h2>}<div className="flex items-start justify-between gap-3 border-b border-border-soft py-4"><div className="min-w-0"><p className="break-words font-medium text-primary">{activityDescription(event)}</p><p className="mt-1 text-sm text-secondary"><time dateTime={new Date(event.occurredAt).toISOString()}>{new Date(event.occurredAt).toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit', second: '2-digit' })}</time> · {event.platform === 'WEB' ? 'Web' : 'Android'}{log.pendingIds.has(event.eventId) ? ' · Pending upload' : ''}</p></div><button type="button" disabled={!log.online || busy} onClick={() => { setError(null); setDeleting(event.eventId) }} aria-label={`Delete activity: ${activityDescription(event)}`} className="grid size-12 shrink-0 place-items-center rounded-control text-secondary hover:bg-control hover:text-primary disabled:opacity-50"><Trash2 className="size-5" aria-hidden="true" /></button></div></li>
      })}</ol>
      {log.hasMore && <Button variant="secondary" onClick={log.loadMore}>Load more</Button>}
    </div>
    <ConfirmDialog open={deleting !== null} title={deleting === 'ALL' ? 'Clear all activity?' : 'Delete this activity?'} message={`This removes ${deleting === 'ALL' ? 'all existing activity' : 'this entry'} from your account across devices. It cannot be undone. Alerts and monitoring records are unaffected.${error ? ` ${error}` : ''}`} confirmLabel={deleting === 'ALL' ? 'Clear all activity' : 'Delete activity'} cancelLabel="Cancel" destructive busy={busy} onConfirm={() => void remove()} onClose={() => { setDeleting(null); setError(null) }} />
  </>
}
