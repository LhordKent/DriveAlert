import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { ArrowLeft } from 'lucide-react'
import { PageHeader } from '../../components/PageHeader'
import { Button } from '../../components/Button'
import { ConfirmDialog } from '../../components/ConfirmDialog'
import { activityRepository } from '../../repositories/activityRepository'
import { useActivityLog } from './useActivityLog'

export function ActivityRetentionPage() {
  const log = useActivityLog()
  const [selection, setSelection] = useState('manual')
  const [custom, setCustom] = useState('')
  const [preview, setPreview] = useState<Awaited<ReturnType<typeof activityRepository.preview>> | null>(null)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [message, setMessage] = useState<string | null>(null)
  useEffect(() => {
    setSelection(log.policy.days === null ? 'manual' : [1, 3, 7].includes(log.policy.days) ? String(log.policy.days) : 'custom')
    setCustom(log.policy.days === null ? '' : String(log.policy.days))
  }, [log.policy.days])
  const days = selection === 'manual' ? null : selection === 'custom' ? Number(custom) : Number(selection)
  const valid = days === null || Number.isInteger(days) && days >= 1 && days <= 3650
  const save = async (confirmed = false) => {
    if (!log.uid || !valid) return
    setBusy(true); setError(null); setMessage(null)
    try {
      if (!confirmed && days !== null && (log.policy.days === null || days < log.policy.days)) setPreview(await activityRepository.preview(log.uid, days))
      else {
        await activityRepository.save(log.uid, confirmed && preview ? preview.days : days, confirmed && preview ? preview.revision : log.policy.revision, confirmed ? preview?.cutoff : undefined)
        setPreview(null); setMessage('Activity retention saved for your account.'); log.refresh()
      }
    } catch (failure) {
      const conflict = failure instanceof Error && failure.message.includes('another device')
      setError(conflict ? 'Activity settings changed on another device. Refresh and review again.' : 'The change could not be confirmed. Connect to the internet and retry.')
      if (conflict) setPreview(null)
      log.refresh()
    }
    finally { setBusy(false) }
  }
  return <>
    <Link to="/settings/activity" className="mb-5 inline-flex min-h-12 items-center gap-2 text-sm font-semibold text-secondary hover:text-primary"><ArrowLeft className="size-4" aria-hidden="true" />Back to Activity Log</Link>
    <PageHeader title="Log retention" description="Choose how long to keep activity across Android and web. Alert-history retention is separate." />
    <form className="max-w-2xl" onSubmit={(event) => { event.preventDefault(); void save() }}>
      {!log.online && <p role="status" className="mb-5 text-sm text-secondary">Connect to the internet to load and change your account’s retention setting.</p>}
      {log.error && <p role="alert" className="mb-4 text-sm text-signal">{log.error}</p>}
      <fieldset disabled={!log.online || busy} className="surface overflow-hidden"><legend className="sr-only">Keep activity for</legend><div className="border-b border-border-soft px-5 py-4"><h2 className="section-title">Keep activity for</h2></div><div className="divide-y divide-border-soft">{[['1', '1 day'], ['3', '3 days'], ['7', '7 days'], ['custom', 'Custom'], ['manual', 'Keep until I delete']].map(([value, label]) => <label key={value} className="flex min-h-14 cursor-pointer items-center gap-3 px-5 py-4 hover:bg-strong"><input type="radio" className="size-5 accent-signal" name="activity-retention" value={value} checked={selection === value} onChange={() => setSelection(value)} /><span>{label}</span></label>)}</div></fieldset>
      {selection === 'custom' && <div className="mt-5"><label htmlFor="activity-days" className="field-label">Number of days</label><input id="activity-days" className="field max-w-xs" type="number" min={1} max={3650} step={1} required value={custom} disabled={!log.online || busy} onChange={(event) => setCustom(event.target.value)} aria-describedby="activity-days-help" aria-invalid={!valid || undefined} /><p id="activity-days-help" className="mt-2 text-sm text-secondary">Enter 1 to 3,650 whole days.</p></div>}
      <div className="mt-5 space-y-3 text-sm leading-6 text-secondary"><p>Each day is 24 hours from the activity’s original time. Expired activity is hidden; cloud cleanup runs when an authenticated device connects. Closed browsers cannot run cleanup.</p><p>You can delete entries or clear the log at any time while online. Increasing the duration never restores removed activity. Alerts, calibration, and monitoring records are unaffected.</p></div>
      {error && !preview && <p role="alert" className="mt-4 text-sm text-signal">{error}</p>}{message && <p role="status" className="mt-4 text-sm text-secondary">{message}</p>}
      <div className="mt-6 flex flex-wrap gap-3"><Button type="submit" busy={busy} disabled={!log.online || !valid || days === log.policy.days}>Save</Button><Button variant="secondary" onClick={log.refresh}>Refresh setting</Button></div>
    </form>
    <ConfirmDialog open={preview !== null} title="Apply automatic log deletion?" message={`This removes ${preview?.count ?? 0} activity ${preview?.count === 1 ? 'entry' : 'entries'} across your account. Older offline entries uploaded later are also removed. This cannot be undone.${error ? ` ${error}` : ''}`} confirmLabel="Save and apply" cancelLabel="Cancel" destructive busy={busy} onConfirm={() => void save(true)} onClose={() => { setPreview(null); setError(null) }} />
  </>
}
