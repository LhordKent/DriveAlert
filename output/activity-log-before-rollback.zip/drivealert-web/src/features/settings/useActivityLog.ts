import { useCallback, useEffect, useState } from 'react'
import { useAuth } from '../../app/providers/authContext'
import { activityRepository } from '../../repositories/activityRepository'
import { activityCutoff, defaultActivityPolicy, type ActivityEvent, type ActivityPolicy } from '../../models/activity'

export function useActivityLog() {
  const { user } = useAuth()
  const uid = user?.uid
  const [owner, setOwner] = useState(uid)
  const [count, setCount] = useState(50)
  const [cloud, setCloud] = useState<ActivityEvent[]>([])
  const [pending, setPending] = useState<ActivityEvent[]>([])
  const [policy, setPolicy] = useState<ActivityPolicy>(defaultActivityPolicy)
  const [deleted, setDeleted] = useState(new Set<string>())
  const [serverReady, setServerReady] = useState(false)
  const [policyReady, setPolicyReady] = useState(false)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [tick, setTick] = useState(0)
  const refresh = useCallback(() => {
    if (!uid) return
    setError(null)
    void activityRepository.flush(uid).then(() => activityRepository.cleanup(uid)).catch(() => setError('Activity could not synchronize. Connect to the internet and retry.'))
    setTick((value) => value + 1)
  }, [uid])
  useEffect(() => {
    if (!uid) return
    let active = true
    const reload = () => { void activityRepository.pending(uid).then((items) => { if (active) { setPending(items); if (activityRepository.hasStorageError()) setError('Some activity could not be saved in this browser. Enable browser storage and retry.') } }).catch(() => { if (active) setError('Activity could not be saved on this browser. Enable browser storage and retry.') }) }
    reload()
    const unsubscribe = activityRepository.subscribe(reload)
    return () => { active = false; unsubscribe() }
  }, [uid])
  useEffect(() => {
    setOwner(uid); setCloud([]); setPending([]); setDeleted(new Set()); setPolicy(defaultActivityPolicy); setPolicyReady(false); setServerReady(false); setLoading(true); setCount(50)
  }, [uid])
  useEffect(() => {
    if (!uid) return
    let active = true
    const failed = () => { if (active) { setLoading(false); setError('Activity could not load. Connect to the internet and retry.') } }
    const stops = [
      activityRepository.observe(uid, count, (items, cached) => { if (active) { setCloud(items); setServerReady(!cached); setLoading(false) } }, failed),
      activityRepository.observePolicy(uid, (value, cached) => { if (active) { setPolicy(value); setPolicyReady(!cached) } }, failed),
      activityRepository.observeDeletions(uid, (ids) => { if (active) setDeleted(ids) }, failed),
    ]
    return () => { active = false; stops.forEach((stop) => stop()) }
  }, [uid, count, tick])
  useEffect(() => {
    refresh()
    const visibleRefresh = () => { if (!document.hidden) refresh() }
    const timer = window.setInterval(visibleRefresh, 60_000)
    window.addEventListener('online', refresh)
    window.addEventListener('focus', visibleRefresh)
    return () => { clearInterval(timer); window.removeEventListener('online', refresh); window.removeEventListener('focus', visibleRefresh) }
  }, [refresh])
  const cutoff = activityCutoff(policy)
  const combined = new Map(cloud.map((event) => [event.eventId, event]))
  pending.forEach((event) => { if (!combined.has(event.eventId)) combined.set(event.eventId, event) })
  const entries = [...combined.values()].filter((event) => event.occurredAt > cutoff && !deleted.has(event.eventId)).sort((a, b) => b.occurredAt - a.occurredAt || b.eventId.localeCompare(a.eventId))
  return { uid, entries: owner === uid ? entries : [], pendingIds: new Set(pending.map((item) => item.eventId)), policy: owner === uid ? policy : defaultActivityPolicy, online: owner === uid && serverReady && policyReady, loading, error, refresh, loadMore: () => setCount((value) => value + 50), hasMore: cloud.length >= count }
}
