export const activityActions = {
  SIGN_IN: ['ACCOUNT', 'Signed in'],
  REGISTER: ['ACCOUNT', 'Created an account'],
  LOGOUT: ['ACCOUNT', 'Logged out'],
  PROFILE_SAVE: ['ACCOUNT', 'Saved profile'],
  SCREEN_VIEW: ['NAVIGATION', 'Opened'],
  DEVICE_CONNECT: ['DEVICE', 'Connected device'],
  DEVICE_DISCONNECT: ['DEVICE', 'Disconnected device'],
  DEVICE_SETUP: ['DEVICE', 'Completed device setup'],
  CALIBRATION_START: ['DEVICE', 'Started calibration'],
  CALIBRATION_COMPLETE: ['DEVICE', 'Completed calibration'],
  CALIBRATION_CANCEL: ['DEVICE', 'Cancelled calibration'],
  MONITORING_START: ['DEVICE', 'Started monitoring'],
  MONITORING_STOP: ['DEVICE', 'Stopped monitoring'],
  MONITORING_PAUSE: ['DEVICE', 'Paused monitoring'],
  MONITORING_RESUME: ['DEVICE', 'Resumed monitoring'],
  CONNECTION_SEND: ['CONNECTIONS', 'Sent connection request'],
  CONNECTION_ACCEPT: ['CONNECTIONS', 'Accepted connection request'],
  CONNECTION_DECLINE: ['CONNECTIONS', 'Declined connection request'],
  CONNECTION_CANCEL: ['CONNECTIONS', 'Cancelled connection request'],
  CONNECTION_REMOVE: ['CONNECTIONS', 'Removed connection'],
  VIEW_CHANGE: ['SETTINGS', 'Changed active view'],
  SOUND_CHANGE: ['SETTINGS', 'Changed warning sound'],
  VOLUME_CHANGE: ['SETTINGS', 'Changed warning volume'],
  NOTIFICATIONS_CHANGE: ['SETTINGS', 'Changed notification preferences'],
  HISTORY_RETENTION: ['SETTINGS', 'Changed alert-history retention'],
  HISTORY_DELETE: ['SETTINGS', 'Deleted alert history'],
} as const

export const activityScreens = {
  dashboard: 'Dashboard', drivers: 'Connected Drivers', requests: 'Requests',
  invite: 'Invite connection', account: 'Account', settings: 'Settings',
  history: 'History & Storage', about: 'About DriveAlert', driver: 'Driver shared history',
  record: 'Shared record details', home: 'Home', alerts: 'Alert History',
  alert: 'Alert details', contacts: 'Trusted Contacts', setup: 'Setup & Device',
  connection: 'Device connection', alignment: 'Camera alignment', calibration: 'Calibration',
  monitoring: 'Monitoring', notifications: 'Notifications', sound: 'Warning Sound',
  view: 'Choose view',
} as const

export type ActivityAction = keyof typeof activityActions
export type ActivityCategory = (typeof activityActions)[ActivityAction][0]
export type ActivityOutcome = 'SUCCESS' | 'FAILURE' | 'REQUESTED'
export interface ActivityEvent {
  eventId: string
  schemaVersion: 1
  occurredAt: number
  platform: 'ANDROID' | 'WEB'
  activeView: 'DRIVER' | 'TRUSTED_CONTACT' | 'UNKNOWN'
  category: ActivityCategory
  action: ActivityAction
  outcome: ActivityOutcome
  detail: string
  operationId: string
}
export interface ActivityPolicy { days: number | null; expiredBefore: number; clearedBefore: number; revision: number }
export const defaultActivityPolicy: ActivityPolicy = { days: null, expiredBefore: 0, clearedBefore: 0, revision: 0 }
export const activityCategories = { ALL: 'All', ACCOUNT: 'Account', NAVIGATION: 'Navigation', DEVICE: 'Device & Monitoring', CONNECTIONS: 'Connections', SETTINGS: 'Settings' } as const
export const ACTIVITY_DAY = 86_400_000
export function activityCutoff(policy: ActivityPolicy, now = Date.now()) {
  return Math.max(policy.expiredBefore, policy.clearedBefore, policy.days === null ? 0 : now - policy.days * ACTIVITY_DAY)
}
export function activityDescription(event: ActivityEvent) {
  const title = activityActions[event.action]?.[1] ?? 'Activity'
  const screen = activityScreens[event.detail as keyof typeof activityScreens]
  const description = event.action === 'SCREEN_VIEW' && screen ? `${title} ${screen}` : title
  return event.outcome === 'FAILURE' ? `${description} — failed` : event.outcome === 'REQUESTED' ? `${description} — requested` : description
}
export function validateActivityDays(days: number | null) {
  if (days !== null && (!Number.isInteger(days) || days < 1 || days > 3650)) throw new Error('Enter 1 to 3,650 whole days.')
}
export function screenForPath(path: string): keyof typeof activityScreens | null {
  if (path.startsWith('/settings/activity')) return null
  if (/^\/drivers\/[^/]+\/records\/[^/]+$/.test(path)) return 'record'
  if (/^\/drivers\/[^/]+$/.test(path)) return 'driver'
  return ({ '/dashboard': 'dashboard', '/drivers': 'drivers', '/requests': 'requests', '/requests/invite': 'invite', '/account': 'account', '/settings': 'settings', '/settings/history': 'history', '/about': 'about' } as const)[path as '/dashboard'] ?? null
}
