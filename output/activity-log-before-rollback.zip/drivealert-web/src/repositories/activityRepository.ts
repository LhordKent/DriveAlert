import { collection, doc, getCountFromServer, getDocsFromServer, limit, onSnapshot, orderBy, query, runTransaction, serverTimestamp, where, writeBatch } from 'firebase/firestore'
import { auth, firestore } from '../firebase/client'
import { ACTIVITY_DAY, activityActions, activityCutoff, defaultActivityPolicy, validateActivityDays, type ActivityAction, type ActivityEvent, type ActivityOutcome, type ActivityPolicy } from '../models/activity'
import { ActivityOutbox } from './activityOutbox'

const outbox = new ActivityOutbox()
const listeners = new Set<() => void>()
let storageError = false
let channel: BroadcastChannel | undefined
const changed = () => { initializeChannel(); listeners.forEach((listener) => listener()); channel?.postMessage('changed') }
function initializeChannel() {
  if (!channel && typeof BroadcastChannel !== 'undefined') {
    try {
      channel = new BroadcastChannel('drivealert-activity')
      channel.onmessage = () => listeners.forEach((listener) => listener())
    } catch { /* Browsers without cross-tab messaging still refresh on entry/focus. */ }
  }
}
const root = (uid: string) => doc(firestore, 'users', uid)
const policyRef = (uid: string) => doc(collection(root(uid), 'activityLogSettings'), 'policy')
const events = (uid: string) => collection(root(uid), 'activityLogs')
const deletions = (uid: string) => collection(root(uid), 'activityLogDeletions')
export const parseActivityPolicy = (data?: Record<string, unknown>): ActivityPolicy => data ? { days: data.days as number | null, expiredBefore: Number(data.expiredBefore), clearedBefore: Number(data.clearedBefore), revision: Number(data.revision) } : { ...defaultActivityPolicy }

export const activityRepository = {
  subscribe(listener: () => void) { initializeChannel(); listeners.add(listener); return () => { listeners.delete(listener) } },
  hasStorageError: () => storageError,
  pending: (uid: string) => outbox.list(uid),
  async recordFor(uid: string, action: ActivityAction, outcome: ActivityOutcome = 'SUCCESS', detail = '', operationId = '') {
    try {
      const event: ActivityEvent = { eventId: crypto.randomUUID(), schemaVersion: 1, occurredAt: Date.now(), platform: 'WEB', activeView: 'TRUSTED_CONTACT', category: activityActions[action][0], action, outcome, detail, operationId }
      await outbox.put(uid, event)
      storageError = false
      changed()
      void this.flush(uid).catch(() => changed())
    } catch { storageError = true; changed() }
  },
  record(action: ActivityAction, outcome: ActivityOutcome = 'SUCCESS', detail = '', operationId = '') {
    const uid = auth.currentUser?.uid
    if (uid) void this.recordFor(uid, action, outcome, detail, operationId)
  },
  async track<T>(action: ActivityAction, operation: () => Promise<T>): Promise<T> {
    const uid = auth.currentUser?.uid
    try {
      const value = await operation()
      if (uid) void this.recordFor(uid, action)
      return value
    } catch (error) { if (uid) void this.recordFor(uid, action, 'FAILURE'); throw error }
  },
  async flush(uid: string) {
    for (const event of await outbox.list(uid)) {
      if (auth.currentUser?.uid !== uid) return
      await runTransaction(firestore, async (tx) => {
        const policy = parseActivityPolicy((await tx.get(policyRef(uid))).data())
        const removed = await tx.get(doc(deletions(uid), event.eventId))
        const ref = doc(events(uid), event.eventId)
        const existing = await tx.get(ref)
        if (!removed.exists() && !existing.exists() && event.occurredAt > activityCutoff(policy)) tx.set(ref, { ...event, receivedAt: serverTimestamp() })
      })
      await outbox.remove(uid, event.eventId)
    }
    changed()
  },
  observe(uid: string, count: number, onValue: (events: ActivityEvent[], fromCache: boolean) => void, onError: () => void) {
    return onSnapshot(query(events(uid), orderBy('occurredAt', 'desc'), orderBy('eventId', 'desc'), limit(count)), { includeMetadataChanges: true }, (snapshot) => onValue(snapshot.docs.map((item) => item.data() as ActivityEvent), snapshot.metadata.fromCache), onError)
  },
  observePolicy(uid: string, onValue: (policy: ActivityPolicy, fromCache: boolean) => void, onError: () => void) {
    return onSnapshot(policyRef(uid), { includeMetadataChanges: true }, (snapshot) => onValue(parseActivityPolicy(snapshot.data()), snapshot.metadata.fromCache), onError)
  },
  observeDeletions(uid: string, onValue: (ids: Set<string>) => void, onError: () => void) {
    return onSnapshot(deletions(uid), (snapshot) => onValue(new Set(snapshot.docs.map((item) => item.id))), onError)
  },
  async preview(uid: string, days: number) {
    validateActivityDays(days)
    const policy = parseActivityPolicy((await getDocsFromServer(query(collection(root(uid), 'activityLogSettings')))).docs.find((item) => item.id === 'policy')?.data())
    const cutoff = Math.max(activityCutoff(policy), Date.now() - days * ACTIVITY_DAY)
    const count = await getCountFromServer(query(events(uid), where('occurredAt', '<=', cutoff)))
    const pending = await outbox.list(uid)
    return { days, count: count.data().count + pending.filter((item) => item.occurredAt <= cutoff).length, revision: policy.revision, cutoff }
  },
  async save(uid: string, days: number | null, revision: number, previewCutoff?: number) {
    validateActivityDays(days)
    await runTransaction(firestore, async (tx) => {
      const ref = policyRef(uid)
      const current = parseActivityPolicy((await tx.get(ref)).data())
      if (current.revision !== revision) throw new Error('Activity settings changed on another device. Refresh and review again.')
      const expiredBefore = Math.max(current.expiredBefore, days === null ? 0 : previewCutoff ?? Date.now() - days * ACTIVITY_DAY)
      tx.set(ref, { ...current, days, expiredBefore, revision: current.revision + 1, updatedAt: serverTimestamp() })
    })
    void this.cleanup(uid).catch(() => { /* A later authenticated refresh retries cleanup. */ })
  },
  async remove(uid: string, id: string) {
    await runTransaction(firestore, async (tx) => {
      // Transaction acknowledgement requires a live server connection.
      await tx.get(policyRef(uid))
      tx.set(doc(deletions(uid), id), { deletedAt: serverTimestamp() })
      tx.delete(doc(events(uid), id))
    })
    await outbox.remove(uid, id)
    changed()
  },
  async clear(uid: string) {
    await runTransaction(firestore, async (tx) => {
      const ref = policyRef(uid)
      const current = parseActivityPolicy((await tx.get(ref)).data())
      tx.set(ref, { ...current, clearedBefore: Math.max(current.clearedBefore, Date.now()), revision: current.revision + 1, updatedAt: serverTimestamp() })
    })
    void this.cleanup(uid).catch(() => {})
  },
  async cleanup(uid: string) {
    let cutoff = 0
    await runTransaction(firestore, async (tx) => {
      const ref = policyRef(uid)
      const snapshot = await tx.get(ref)
      const current = parseActivityPolicy(snapshot.data())
      cutoff = activityCutoff(current)
      if (cutoff > Math.max(current.expiredBefore, current.clearedBefore)) tx.set(ref, { ...current, expiredBefore: cutoff, revision: current.revision + 1, updatedAt: serverTimestamp() })
    })
    // Bound each pass; subsequent focus/timer passes continue large cleanups.
    const old = await getDocsFromServer(query(events(uid), where('occurredAt', '<=', cutoff), limit(200)))
    if (!old.empty) {
      const batch = writeBatch(firestore)
      old.docs.forEach((item) => batch.delete(item.ref))
      await batch.commit()
    }
    for (const item of await outbox.list(uid)) if (item.occurredAt <= cutoff) await outbox.remove(uid, item.eventId)
  },
}
