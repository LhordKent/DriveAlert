import type { ActivityEvent } from '../models/activity'

/** A dedicated database: clearing alert history never changes pending activity. */
export class ActivityOutbox {
  constructor(private readonly factory: () => IDBFactory = () => indexedDB) {}
  private async transact<T>(mode: IDBTransactionMode, operation: (store: IDBObjectStore) => IDBRequest<T>): Promise<T> {
    const db = await new Promise<IDBDatabase>((resolve, reject) => {
      const request = this.factory().open('drivealert-activity-v1', 1)
      request.onupgradeneeded = () => {
        request.result.createObjectStore('outbox', { keyPath: ['uid', 'eventId'] }).createIndex('uid', 'uid')
      }
      request.onsuccess = () => resolve(request.result)
      request.onerror = () => reject(request.error)
      request.onblocked = () => reject(new Error('Close other DriveAlert tabs and retry.'))
    })
    return new Promise((resolve, reject) => {
      const tx = db.transaction('outbox', mode)
      const request = operation(tx.objectStore('outbox'))
      tx.oncomplete = () => { db.close(); resolve(request.result) }
      tx.onabort = tx.onerror = () => { db.close(); reject(tx.error ?? new Error('Activity storage unavailable.')) }
    })
  }
  async put(uid: string, event: ActivityEvent) { await this.transact('readwrite', (store) => store.put({ uid, eventId: event.eventId, event })) }
  async remove(uid: string, id: string) { await this.transact('readwrite', (store) => store.delete([uid, id])) }
  async list(uid: string): Promise<ActivityEvent[]> {
    return (await this.transact('readonly', (store) => store.index('uid').getAll(uid))).map((row: { event: ActivityEvent }) => row.event)
  }
}
