import {
  createUserWithEmailAndPassword,
  onAuthStateChanged,
  sendPasswordResetEmail,
  signInWithEmailAndPassword,
  signOut,
  updateProfile,
  type User,
} from 'firebase/auth'
import { auth } from '../firebase/client'
import { activityRepository } from './activityRepository'

export interface RegistrationInput {
  firstName: string
  middleName?: string
  lastName: string
  phoneNumber?: string
  email: string
  password: string
}

export const authRepository = {
  observe(callback: (user: User | null) => void) {
    return onAuthStateChanged(auth, callback)
  },
  async signIn(email: string, password: string) {
    const result = await signInWithEmailAndPassword(auth, email.trim().toLowerCase(), password)
    void activityRepository.recordFor(result.user.uid, 'SIGN_IN')
    return result
  },
  async register(input: RegistrationInput) {
    const credential = await createUserWithEmailAndPassword(auth, input.email.trim().toLowerCase(), input.password)
    void activityRepository.recordFor(credential.user.uid, 'REGISTER')
    const name = [input.firstName, input.middleName, input.lastName].filter(Boolean).join(' ')
    await updateProfile(credential.user, { displayName: name })
    return credential.user
  },
  async resetPassword(email: string) {
    await sendPasswordResetEmail(auth, email.trim().toLowerCase())
  },
  async logout() {
    const uid = auth.currentUser?.uid
    if (uid) await activityRepository.recordFor(uid, 'LOGOUT')
    await signOut(auth)
  },
}
