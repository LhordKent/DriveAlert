import { useEffect, useMemo, useState, type ReactNode } from 'react'
import type { User } from 'firebase/auth'
import { authRepository } from '../../repositories/authRepository'
import { AuthContext } from './authContext'
import { activityRepository } from '../../repositories/activityRepository'

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => authRepository.observe((nextUser) => {
    setUser(nextUser)
    setLoading(false)
  }), [])

  const value = useMemo(() => ({ user, loading }), [user, loading])
  useEffect(() => {
    if (!user) return
    const uid = user.uid
    const refresh = () => { if (!document.hidden) void activityRepository.flush(uid).then(() => activityRepository.cleanup(uid)).catch(() => {}) }
    refresh()
    const timer = window.setInterval(refresh, 60_000)
    window.addEventListener('online', refresh)
    window.addEventListener('focus', refresh)
    return () => { clearInterval(timer); window.removeEventListener('online', refresh); window.removeEventListener('focus', refresh) }
  }, [user])
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}
