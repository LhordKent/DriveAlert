import 'fake-indexeddb/auto'
import { describe, expect, it } from 'vitest'
import { ActivityOutbox } from '../src/repositories/activityOutbox'
import { ACTIVITY_DAY, activityActions, activityCutoff, activityDescription, defaultActivityPolicy, screenForPath, validateActivityDays, type ActivityEvent } from '../src/models/activity'

const event = (eventId: string): ActivityEvent => ({ eventId, schemaVersion: 1, occurredAt: 100, platform: 'WEB', activeView: 'TRUSTED_CONTACT', category: 'ACCOUNT', action: 'SIGN_IN', outcome: 'SUCCESS', detail: '', operationId: '' })
describe('activity storage and contract', () => {
  it('isolates accounts, survives repository recreation, and keeps retry IDs stable', async () => {
    const first = new ActivityOutbox()
    await first.put('a', event('same'))
    await first.put('a', event('same'))
    await first.put('b', event('same'))
    const restored = new ActivityOutbox()
    expect(await restored.list('a')).toEqual([event('same')])
    await restored.remove('a', 'same')
    expect(await first.list('a')).toEqual([])
    expect(await first.list('b')).toEqual([event('same')])
  })
  it('uses original time, preserves removal cutoffs, and validates custom periods', () => {
    const now = 20 * ACTIVITY_DAY
    expect(activityCutoff(defaultActivityPolicy, now)).toBe(0)
    expect(activityCutoff({ ...defaultActivityPolicy, days: 3 }, now)).toBe(17 * ACTIVITY_DAY)
    expect(activityCutoff({ days: null, expiredBefore: 18 * ACTIVITY_DAY, clearedBefore: 19 * ACTIVITY_DAY, revision: 3 }, now)).toBe(19 * ACTIVITY_DAY)
    for (const days of [null, 1, 3, 7, 3650]) expect(() => validateActivityDays(days)).not.toThrow()
    for (const days of [0, -1, 1.5, 3651, NaN]) expect(() => validateActivityDays(days)).toThrow()
  })
  it('formats safe descriptions and excludes the log itself from navigation recording', () => {
    expect(activityDescription({ ...event('x'), action: 'SCREEN_VIEW', category: 'NAVIGATION', detail: 'account' })).toBe('Opened Account')
    expect(activityDescription({ ...event('x'), outcome: 'FAILURE' })).toBe('Signed in — failed')
    expect(screenForPath('/settings/activity')).toBeNull()
    expect(screenForPath('/settings/activity/retention')).toBeNull()
    expect(screenForPath('/drivers/private-id/records/private-record')).toBe('record')
    expect(Object.keys(activityActions)).toHaveLength(26)
  })
})
