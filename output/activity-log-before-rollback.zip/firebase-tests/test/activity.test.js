const assert = require('node:assert/strict');
const { initializeApp, deleteApp } = require('firebase/app');
const { connectAuthEmulator, createUserWithEmailAndPassword, getAuth, signInWithEmailAndPassword } = require('firebase/auth');
const { connectFirestoreEmulator, getFirestore, doc, collection, getDoc, getDocs, setDoc, updateDoc, deleteDoc, serverTimestamp, runTransaction, writeBatch, query, orderBy, limit } = require('firebase/firestore');
const project = 'drivealert-lhordkent';
const address = process.env.FIRESTORE_EMULATOR_HOST || '127.0.0.1:8080';
let index = 0;
const apps = [];
async function client(email) {
  const app = initializeApp({ projectId: project, apiKey: 'demo-key', appId: 'activity-test' }, `activity-${++index}`);
  apps.push(app);
  const auth = getAuth(app); connectAuthEmulator(auth, 'http://127.0.0.1:9099', { disableWarnings: true });
  const db = getFirestore(app); connectFirestoreEmulator(db, '127.0.0.1', Number(address.split(':').at(-1)));
  const credential = email ? await signInWithEmailAndPassword(auth, email, 'Password123!') : await createUserWithEmailAndPassword(auth, `activity-${index}@example.com`, 'Password123!');
  return { db, uid: credential.user.uid, email: credential.user.email };
}
const ref = (c, kind, id) => doc(c.db, 'users', c.uid, kind, id);
const event = (id, overrides = {}) => ({ eventId: id, schemaVersion: 1, occurredAt: Date.now(), platform: 'ANDROID', activeView: 'DRIVER', category: 'ACCOUNT', action: 'SIGN_IN', outcome: 'SUCCESS', detail: '', operationId: '', receivedAt: serverTimestamp(), ...overrides });
const policy = (overrides = {}) => ({ days: null, expiredBefore: 0, clearedBefore: 0, revision: 1, updatedAt: serverTimestamp(), ...overrides });
const denied = (operation) => assert.rejects(operation, error => error.code === 'permission-denied');

describe('Private account activity rules', () => {
  beforeEach(async () => {
    await fetch(`http://${address}/emulator/v1/projects/${project}/databases/(default)/documents`, { method: 'DELETE' });
    await fetch(`http://127.0.0.1:9099/emulator/v1/projects/${project}/accounts`, { method: 'DELETE' });
  });
  afterEach(async () => Promise.all(apps.splice(0).map(deleteApp)));
  it('shares Android and web activity only with the same account', async () => {
    const owner = await client(); const web = await client(owner.email); const other = await client();
    await setDoc(ref(owner, 'activityLogs', 'a'), event('a'));
    await setDoc(ref(web, 'activityLogs', 'w'), event('w', { platform: 'WEB', activeView: 'TRUSTED_CONTACT' }));
    const q = query(collection(web.db, 'users', owner.uid, 'activityLogs'), orderBy('occurredAt', 'desc'), orderBy('eventId', 'desc'), limit(50));
    assert.equal((await getDocs(q)).size, 2);
    await denied(getDoc(doc(other.db, 'users', owner.uid, 'activityLogs', 'a')));
    await denied(getDocs(collection(other.db, 'users', owner.uid, 'activityLogs')));
    await denied(setDoc(doc(other.db, 'users', owner.uid, 'activityLogs', 'x'), event('x')));
  });
  it('rejects edits, malformed events and unapproved metadata', async () => {
    const c = await client();
    await setDoc(ref(c, 'activityLogs', 'a'), event('a'));
    await denied(updateDoc(ref(c, 'activityLogs', 'a'), { outcome: 'FAILURE' }));
    for (const [i, overrides] of [{ schemaVersion: 2 }, { category: 'DEVICE' }, { action: 'UNKNOWN' }, { detail: 'secret connection code' }, { password: 'secret' }, { occurredAt: 1.5 }, { receivedAt: new Date(0) }].entries()) {
      await denied(setDoc(ref(c, 'activityLogs', `bad-${i}`), event(`bad-${i}`, overrides)));
    }
  });
  it('requires a deletion marker and blocks later recreation', async () => {
    const c = await client(); const otherDevice = await client(c.email);
    await setDoc(ref(c, 'activityLogs', 'a'), event('a'));
    await denied(deleteDoc(ref(c, 'activityLogs', 'a')));
    const batch = writeBatch(c.db);
    batch.set(ref(c, 'activityLogDeletions', 'a'), { deletedAt: serverTimestamp() });
    batch.delete(ref(c, 'activityLogs', 'a')); await batch.commit();
    assert.equal((await getDoc(ref(c, 'activityLogs', 'a'))).exists(), false);
    await denied(setDoc(ref(otherDevice, 'activityLogs', 'a'), event('a')));
    await denied(deleteDoc(ref(c, 'activityLogDeletions', 'a')));
  });
  it('clear cutoff blocks pending offline uploads but allows future activity', async () => {
    const c = await client(); const at = Date.now() - 5000;
    await setDoc(ref(c, 'activityLogs', 'old'), event('old', { occurredAt: at }));
    await setDoc(ref(c, 'activityLogSettings', 'policy'), policy({ clearedBefore: at + 1000 }));
    await deleteDoc(ref(c, 'activityLogs', 'old'));
    await denied(setDoc(ref(c, 'activityLogs', 'delayed'), event('delayed', { occurredAt: at })));
    await setDoc(ref(c, 'activityLogs', 'new'), event('new'));
  });
  it('enforces retention, monotonic cutoffs, and revision checks', async () => {
    const c = await client(); const p = ref(c, 'activityLogSettings', 'policy'); const cutoff = Date.now() - 86400000;
    await setDoc(p, policy({ days: 1, expiredBefore: cutoff }));
    await denied(setDoc(ref(c, 'activityLogs', 'expired'), event('expired', { occurredAt: cutoff - 1 })));
    await denied(updateDoc(p, { expiredBefore: 0, revision: 2, updatedAt: serverTimestamp() }));
    await denied(updateDoc(p, { days: 7, revision: 1, updatedAt: serverTimestamp() }));
    await updateDoc(p, { days: null, revision: 2, updatedAt: serverTimestamp() });
    await denied(setDoc(ref(c, 'activityLogs', 'still-expired'), event('still-expired', { occurredAt: cutoff })));
    await denied(deleteDoc(p));
    for (const days of [0, 3651, 1.5]) await denied(updateDoc(p, { days, revision: 3, updatedAt: serverTimestamp() }));
  });
  it('transactions prevent concurrent policy writes from losing revisions', async () => {
    const c = await client(); const otherDevice = await client(c.email);
    await setDoc(ref(c, 'activityLogSettings', 'policy'), policy());
    const results = await Promise.allSettled([c, otherDevice].map(device => runTransaction(device.db, async tx => {
      const p = ref(device, 'activityLogSettings', 'policy'); const current = (await tx.get(p)).data();
      tx.update(p, { days: 7, revision: current.revision + 1, updatedAt: serverTimestamp() });
    })));
    const completed = results.filter(result => result.status === 'fulfilled').length;
    assert.ok(completed >= 1);
    assert.equal((await getDoc(ref(c, 'activityLogSettings', 'policy'))).data().revision, 1 + completed);
    // A stale revision can be denied before the emulator retries a transaction.
    // The client must refresh and ask the user to review the current policy.
    for (const result of results) if (result.status === 'rejected') assert.equal(result.reason.code, 'permission-denied');
  });
});
