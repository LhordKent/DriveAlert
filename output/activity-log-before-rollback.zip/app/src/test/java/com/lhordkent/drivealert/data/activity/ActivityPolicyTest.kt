package com.lhordkent.drivealert.data.activity

import org.junit.Assert.*
import org.junit.Test

class ActivityPolicyTest {
    @Test fun retentionUsesOriginalTimeAndPreservesRemovalCutoffs() {
        val now = 20 * ACTIVITY_DAY
        assertEquals(0, ActivityPolicy().cutoff(now))
        assertEquals(17 * ACTIVITY_DAY, ActivityPolicy(days = 3).cutoff(now))
        assertEquals(19 * ACTIVITY_DAY, ActivityPolicy(days = null, expiredBefore = 18 * ACTIVITY_DAY, clearedBefore = 19 * ACTIVITY_DAY).cutoff(now))
        listOf(null, 1, 3, 7, 3650).forEach(::validateActivityDays)
        listOf(0, -1, 3651).forEach { assertThrows(IllegalArgumentException::class.java) { validateActivityDays(it) } }
    }
    @Test fun descriptionsDistinguishOutcomeWithoutExposingIdentifiers() {
        val entry = ActivityEntry("private-uid", "private-id", 1, "ANDROID", "DRIVER", "NAVIGATION", "SCREEN_VIEW", "SUCCESS", "account")
        assertEquals("Opened Account", entry.description())
        assertEquals("Saved profile — failed", entry.copy(action = "PROFILE_SAVE", outcome = "FAILURE").description())
        assertEquals(26, ActivityAction.values().size)
    }
}
