package com.lhordkent.drivealert.ui.postauth

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.lhordkent.drivealert.data.activity.*
import com.lhordkent.drivealert.ui.theme.*
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle

@Composable
fun ActivityLogScreen(model: ActivityLogViewModel, onBack: () -> Unit, onRetention: () -> Unit) {
    val storageFailed by model.storageError.collectAsState()
    var category by rememberSaveable { mutableStateOf("ALL") }
    var expanded by remember { mutableStateOf(false) }
    var deleteId by rememberSaveable { mutableStateOf<String?>(null) }
    var clear by rememberSaveable { mutableStateOf(false) }
    val entries = model.entries.filter { category == "ALL" || it.category == category }
    ScrollableScreen("Activity Log", onBack) {
        Text("Your actions across Android and web. Only you can see this activity.", color = TextSecondary)
        Spacer(Modifier.height(16.dp))
        SecondaryButton("Log retention", onRetention)
        Spacer(Modifier.height(8.dp))
        SecondaryButton("Refresh activity", model::refresh)
        Spacer(Modifier.height(8.dp))
        SecondaryButton("Clear all activity", { clear = true }, enabled = model.online && !model.busy && model.entries.isNotEmpty())
        Spacer(Modifier.height(16.dp))
        Text(model.policy.days?.let { "Automatically removed after $it days." } ?: "Kept until you delete it.", color = TextSecondary)
        if (!model.online) {
            Spacer(Modifier.height(10.dp))
            Text("Showing locally available activity. Cloud history may be out of date. Connect to delete activity or change retention.", color = TextSecondary)
        }
        Spacer(Modifier.height(16.dp))
        Box {
            SecondaryButton("Category: ${activityCategories[category]}", { expanded = true })
            DropdownMenu(expanded, { expanded = false }) {
                activityCategories.forEach { (key, label) -> DropdownMenuItem(text = { Text(label) }, onClick = { category = key; expanded = false }) }
            }
        }
        Text("Filters loaded activity. Load more to include earlier entries.", style = MaterialTheme.typography.bodySmall, color = TextMuted)
        Spacer(Modifier.height(12.dp))
        HistoryFeedback(model.error, model.message)
        if (storageFailed) Text("Some activity could not be saved on this phone. Check available storage and retry.", color = DriveRed)
        if (model.loading) Text("Loading activity…", color = TextSecondary)
        if (!model.loading && entries.isEmpty()) {
            Text("No activity to show", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
            Text("Activity appears as you use DriveAlert. Older activity is not added retroactively.", color = TextSecondary)
        }
        var previousDate = ""
        entries.forEach { entry ->
            val time = Instant.ofEpochMilli(entry.occurredAt).atZone(ZoneId.systemDefault())
            val date = time.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.LONG))
            if (date != previousDate) {
                Spacer(Modifier.height(22.dp)); SectionTitle(date); previousDate = date
            }
            Spacer(Modifier.height(12.dp))
            Text(entry.description(), style = MaterialTheme.typography.bodyLarge, color = TextPrimary)
            Text("${time.format(DateTimeFormatter.ofPattern("h:mm:ss a"))} · ${if (entry.platform == "WEB") "Web" else "Android"}${if (entry.pending) " · Pending upload" else ""}", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
            TextButton(onClick = { deleteId = entry.eventId }, enabled = model.online && !model.busy) { Text("Delete activity") }
            HorizontalDivider(color = Border)
        }
        if (model.hasMore) { Spacer(Modifier.height(16.dp)); SecondaryButton("Load more", model::loadMore) }
        Spacer(Modifier.height(24.dp))
    }
    if (clear || deleteId != null) ConfirmDialog(
        if (clear) "Clear all activity?" else "Delete this activity?",
        "This removes ${if (clear) "all existing activity" else "this entry"} from your account across devices. Deletion cannot be undone. Alerts and monitoring records are unaffected.",
        if (clear) "Clear all activity" else "Delete activity",
        onConfirm = { if (clear) model.clear() else deleteId?.let(model::remove); clear = false; deleteId = null },
        onDismiss = { clear = false; deleteId = null },
    )
}

@Composable
fun ActivityRetentionScreen(model: ActivityLogViewModel, onBack: () -> Unit) {
    var selected by rememberSaveable { mutableStateOf(0) }
    var custom by rememberSaveable { mutableStateOf("") }
    LaunchedEffect(model.policy.days) {
        val days = model.policy.days
        selected = when (days) { null -> 0; 1, 3, 7 -> days; else -> -1 }
        custom = if (selected == -1) days.toString() else ""
    }
    val days = when (selected) { 0 -> null; -1 -> custom.toIntOrNull(); else -> selected }
    val valid = selected != -1 || days != null && days in 1..3650
    val enabled = model.online && !model.busy
    ScrollableScreen("Log retention", onBack) {
        Text("Choose how long to keep activity", style = MaterialTheme.typography.headlineSmall, color = TextPrimary)
        Spacer(Modifier.height(8.dp))
        Text("Applies to your account across Android and web. Alert-history retention is separate.", color = TextSecondary)
        if (!model.online) { Spacer(Modifier.height(10.dp)); Text("Connect to load and change your account’s retention setting.", color = TextSecondary) }
        Spacer(Modifier.height(20.dp))
        Column(Modifier.selectableGroup()) {
            listOf(1 to "1 day", 3 to "3 days", 7 to "7 days", -1 to "Custom", 0 to "Keep until I delete").forEach { (value, label) ->
                Row(Modifier.fillMaxWidth().heightIn(min = 56.dp).selectable(selected == value, enabled, Role.RadioButton) { selected = value }.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected == value, null, enabled = enabled); Spacer(Modifier.width(12.dp)); Text(label, color = TextPrimary)
                }
            }
        }
        if (selected == -1) OutlinedTextField(custom, { custom = it.take(5) }, label = { Text("Number of days") }, supportingText = { Text("Enter 1 to 3,650 whole days.") }, isError = custom.isNotEmpty() && !valid, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, enabled = enabled, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(20.dp))
        Text("Each day is 24 hours from the activity’s original time. Expired activity is hidden; cloud cleanup runs when an authenticated device connects. Background cleanup may be delayed by Android.", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
        Spacer(Modifier.height(10.dp))
        Text("You can delete activity while online. Increasing the duration never restores removed entries. Alerts, calibration, and monitoring records are unaffected.", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
        Spacer(Modifier.height(20.dp))
        HistoryFeedback(model.error, model.message)
        PrimaryButton(if (model.busy) "Saving…" else "Save", { model.save(days) }, enabled = enabled && valid && days != model.policy.days)
        Spacer(Modifier.height(8.dp)); SecondaryButton("Refresh setting", model::refresh)
        Spacer(Modifier.height(24.dp))
    }
    model.preview?.let { preview -> ConfirmDialog("Apply automatic log deletion?",
        "This removes ${preview.count} activity entries across your account. Older offline entries uploaded later are also removed. This cannot be undone.${model.error?.let { "\n\n$it" }.orEmpty()}",
        if (model.busy) "Saving…" else "Save and apply", model::confirmRetention, model::dismissPreview) }
}
