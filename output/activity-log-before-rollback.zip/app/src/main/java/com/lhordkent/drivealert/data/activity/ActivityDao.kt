package com.lhordkent.drivealert.data.activity

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "activity_entries", primaryKeys = ["uid", "eventId"], indices = [Index(value = ["uid", "occurredAt"])])
data class ActivityEntry(
    val uid: String, val eventId: String, val occurredAt: Long, val platform: String,
    val activeView: String, val category: String, val action: String, val outcome: String,
    val detail: String = "", val operationId: String = "", val pending: Boolean = true,
)
@Entity(tableName = "activity_policies")
data class CachedActivityPolicy(@PrimaryKey val uid: String, val days: Int?, val expiredBefore: Long, val clearedBefore: Long, val revision: Long) {
    fun policy() = ActivityPolicy(days, expiredBefore, clearedBefore, revision)
}
@Dao
interface ActivityDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun insert(entry: ActivityEntry)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertPolicy(policy: CachedActivityPolicy)
    @Transaction suspend fun savePolicy(value: CachedActivityPolicy) {
        if (value.revision >= (policy(value.uid)?.revision ?: -1)) insertPolicy(value)
    }
    @Query("SELECT * FROM activity_policies WHERE uid = :uid") suspend fun policy(uid: String): CachedActivityPolicy?
    @Query("SELECT * FROM activity_entries WHERE uid = :uid ORDER BY occurredAt DESC, eventId DESC LIMIT :count") fun observe(uid: String, count: Int = 50): Flow<List<ActivityEntry>>
    @Query("SELECT COUNT(*) FROM activity_entries WHERE uid = :uid AND pending = 1 AND occurredAt <= :cutoff") suspend fun pendingBefore(uid: String, cutoff: Long): Long
    @Query("SELECT * FROM activity_entries WHERE uid = :uid AND pending = 1 ORDER BY occurredAt LIMIT 100") suspend fun pending(uid: String): List<ActivityEntry>
    @Query("UPDATE activity_entries SET pending = 0 WHERE uid = :uid AND eventId = :id") suspend fun uploaded(uid: String, id: String)
    @Query("DELETE FROM activity_entries WHERE uid = :uid AND eventId = :id") suspend fun remove(uid: String, id: String)
    @Query("DELETE FROM activity_entries WHERE uid = :uid AND occurredAt <= :cutoff") suspend fun expire(uid: String, cutoff: Long)
}
