package com.lhordkent.drivealert.ui

internal fun activityScreenForRoute(route: String?): String? = when (route) {
    PostAuthRoutes.ROLE_CHOICE -> "view"
    PostAuthRoutes.DRIVER_SETUP -> "setup"
    PostAuthRoutes.DRIVER_DEVICE_CONNECTION -> "connection"
    PostAuthRoutes.DRIVER_ALIGNMENT -> "alignment"
    PostAuthRoutes.DRIVER_CALIBRATION -> "calibration"
    PostAuthRoutes.DRIVER_HOME -> "home"
    PostAuthRoutes.DRIVER_MONITORING -> "monitoring"
    PostAuthRoutes.DRIVER_ALERTS -> "alerts"
    PostAuthRoutes.DRIVER_ALERT_DETAIL -> "alert"
    PostAuthRoutes.DRIVER_CONTACTS -> "contacts"
    PostAuthRoutes.DRIVER_INVITE, PostAuthRoutes.TRUSTED_INVITE -> "invite"
    PostAuthRoutes.DRIVER_SETTINGS, PostAuthRoutes.TRUSTED_SETTINGS -> "settings"
    PostAuthRoutes.TRUSTED_DRIVERS -> "drivers"
    PostAuthRoutes.TRUSTED_SHARED -> "driver"
    PostAuthRoutes.TRUSTED_ALERT_DETAIL -> "record"
    PostAuthRoutes.TRUSTED_REQUESTS -> "requests"
    PostAuthRoutes.ACCOUNT -> "account"
    PostAuthRoutes.HISTORY_STORAGE -> "history"
    PostAuthRoutes.NOTIFICATIONS -> "notifications"
    PostAuthRoutes.WARNING_SOUND -> "sound"
    PostAuthRoutes.ABOUT -> "about"
    else -> null
}
