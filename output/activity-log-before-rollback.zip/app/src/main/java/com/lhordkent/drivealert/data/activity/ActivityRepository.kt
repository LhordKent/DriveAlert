package com.lhordkent.drivealert.data.activity

import android.content.Context
import androidx.work.*
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.*
import com.lhordkent.drivealert.DriveAlertApplication
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.tasks.await
import java.util.UUID
import java.util.concurrent.TimeUnit

class ActivityRepository(private val context: Context, private val dao: ActivityDao, private val firestore: FirebaseFirestore) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val lock = Mutex()
    private val _storageError = MutableStateFlow(false)
    val storageError = _storageError.asStateFlow()
    private fun localWork(operation: suspend () -> Unit) = scope.launch {
        try { operation() }
        catch (cancelled: CancellationException) { throw cancelled }
        catch (_: Exception) { _storageError.value = true }
    }
    var activeView: String = "UNKNOWN"
    private fun root(uid: String) = firestore.collection("users").document(uid)
    private fun events(uid: String) = root(uid).collection("activityLogs")
    private fun policyRef(uid: String) = root(uid).collection("activityLogSettings").document("policy")
    private fun deletions(uid: String) = root(uid).collection("activityLogDeletions")
    private fun policy(data: DocumentSnapshot): ActivityPolicy = if (!data.exists()) ActivityPolicy() else ActivityPolicy(
        data.getLong("days")?.toInt(), data.getLong("expiredBefore") ?: 0, data.getLong("clearedBefore") ?: 0, data.getLong("revision") ?: 0,
    )
    fun observe(uid: String, count: Int = 50) = dao.observe(uid, count)
    suspend fun cachedPolicy(uid: String) = dao.policy(uid)?.policy() ?: ActivityPolicy()
    private suspend fun cache(uid: String, p: ActivityPolicy) {
        dao.savePolicy(CachedActivityPolicy(uid, p.days, p.expiredBefore, p.clearedBefore, p.revision))
        dao.expire(uid, p.cutoff())
    }
    fun record(action: ActivityAction, outcome: String = "SUCCESS", detail: String = "", operationId: String = "", uid: String? = FirebaseAuth.getInstance().currentUser?.uid) {
        if (uid == null) return
        val entry = ActivityEntry(uid, UUID.randomUUID().toString(), System.currentTimeMillis(), "ANDROID", activeView, action.category, action.name, outcome, detail, operationId)
        scope.launch {
            try { dao.insert(entry); _storageError.value = false; schedule(uid) }
            catch (cancelled: CancellationException) { throw cancelled }
            catch (_: Exception) { _storageError.value = true }
        }
    }
    suspend fun <T> track(action: ActivityAction, uid: String, operation: suspend () -> T): T = try {
        operation().also { record(action, uid = uid) }
    } catch (cancelled: CancellationException) { throw cancelled }
    catch (error: Exception) { record(action, "FAILURE", uid = uid); throw error }

    private fun wire(entry: ActivityEntry) = mapOf(
        "eventId" to entry.eventId, "schemaVersion" to 1, "occurredAt" to entry.occurredAt,
        "platform" to entry.platform, "activeView" to entry.activeView, "category" to entry.category,
        "action" to entry.action, "outcome" to entry.outcome, "detail" to entry.detail,
        "operationId" to entry.operationId, "receivedAt" to FieldValue.serverTimestamp(),
    )
    fun decode(uid: String, data: DocumentSnapshot): ActivityEntry? = runCatching {
        val action = ActivityAction.valueOf(data.getString("action")!!)
        ActivityEntry(uid, data.id, data.getLong("occurredAt")!!, data.getString("platform")!!,
            data.getString("activeView")!!, action.category, action.name, data.getString("outcome")!!,
            data.getString("detail").orEmpty(), data.getString("operationId").orEmpty(), false)
    }.getOrNull()

    suspend fun synchronize(uid: String): Boolean = lock.withLock {
        require(FirebaseAuth.getInstance().currentUser?.uid == uid)
        refreshPolicy(uid)
        for (removed in deletions(uid).get(Source.SERVER).await()) dao.remove(uid, removed.id)
        for (entry in dao.pending(uid)) {
            require(FirebaseAuth.getInstance().currentUser?.uid == uid)
            val keep = firestore.runTransaction { tx ->
                val current = policy(tx.get(policyRef(uid)))
                val removed = tx.get(deletions(uid).document(entry.eventId))
                val ref = events(uid).document(entry.eventId)
                val existing = tx.get(ref)
                val eligible = !removed.exists() && entry.occurredAt > current.cutoff()
                if (eligible && !existing.exists()) tx.set(ref, wire(entry))
                eligible
            }.await()
            if (keep) dao.uploaded(uid, entry.eventId) else dao.remove(uid, entry.eventId)
        }
        cleanup(uid)
        dao.pending(uid).isEmpty()
    }
    suspend fun refreshPolicy(uid: String): ActivityPolicy {
        val p = policy(policyRef(uid).get(Source.SERVER).await())
        cache(uid, p)
        return p
    }
    fun observePolicy(uid: String, onValue: (ActivityPolicy, Boolean) -> Unit, onError: () -> Unit): ListenerRegistration =
        policyRef(uid).addSnapshotListener(MetadataChanges.INCLUDE) { snapshot, error ->
            if (error != null || snapshot == null) onError() else {
                val p = policy(snapshot)
                localWork { cache(uid, p) }
                onValue(p, snapshot.metadata.isFromCache)
            }
        }
    fun observeDeletions(uid: String, onValue: (Set<String>) -> Unit, onError: () -> Unit): ListenerRegistration =
        deletions(uid).addSnapshotListener { snapshot, error ->
            if (error != null || snapshot == null) onError() else {
                val ids = snapshot.documents.map { it.id }.toSet()
                localWork { ids.forEach { dao.remove(uid, it) } }
                onValue(ids)
            }
        }
    fun observeCloud(uid: String, count: Long, onValue: (List<ActivityEntry>, Boolean) -> Unit, onError: () -> Unit): ListenerRegistration =
        events(uid).orderBy("occurredAt", Query.Direction.DESCENDING).orderBy("eventId", Query.Direction.DESCENDING).limit(count)
            .addSnapshotListener(MetadataChanges.INCLUDE) { snapshot, error ->
                if (error != null || snapshot == null) onError()
                else onValue(snapshot.documents.mapNotNull { decode(uid, it) }, snapshot.metadata.isFromCache)
            }
    data class Preview(val days: Int, val count: Long, val revision: Long, val cutoff: Long)
    suspend fun preview(uid: String, days: Int): Preview {
        validateActivityDays(days)
        val p = refreshPolicy(uid)
        val cutoff = maxOf(p.cutoff(), System.currentTimeMillis() - days * ACTIVITY_DAY)
        val count = events(uid).whereLessThanOrEqualTo("occurredAt", cutoff).count().get(AggregateSource.SERVER).await().count
        return Preview(days, count + dao.pendingBefore(uid, cutoff), p.revision, cutoff)
    }
    suspend fun save(uid: String, days: Int?, revision: Long, previewCutoff: Long? = null) {
        validateActivityDays(days)
        firestore.runTransaction { tx ->
            val ref = policyRef(uid)
            val current = policy(tx.get(ref))
            check(current.revision == revision) { "Activity settings changed on another device. Refresh and review again." }
            val cutoff = maxOf(current.expiredBefore, days?.let { previewCutoff ?: System.currentTimeMillis() - it * ACTIVITY_DAY } ?: 0)
            tx.set(ref, policyWire(current.copy(days = days, expiredBefore = cutoff, revision = current.revision + 1)))
        }.await()
        refreshPolicy(uid)
        schedule(uid)
    }
    private fun policyWire(p: ActivityPolicy) = mapOf("days" to p.days, "expiredBefore" to p.expiredBefore, "clearedBefore" to p.clearedBefore, "revision" to p.revision, "updatedAt" to FieldValue.serverTimestamp())
    suspend fun remove(uid: String, id: String) {
        firestore.runTransaction { tx ->
            tx.get(policyRef(uid))
            tx.set(deletions(uid).document(id), mapOf("deletedAt" to FieldValue.serverTimestamp()))
            tx.delete(events(uid).document(id))
        }.await()
        dao.remove(uid, id)
    }
    suspend fun clear(uid: String) {
        firestore.runTransaction { tx ->
            val p = policy(tx.get(policyRef(uid)))
            tx.set(policyRef(uid), policyWire(p.copy(clearedBefore = maxOf(p.clearedBefore, System.currentTimeMillis()), revision = p.revision + 1)))
        }.await()
        refreshPolicy(uid)
        schedule(uid)
    }
    private suspend fun cleanup(uid: String) {
        val p = firestore.runTransaction { tx ->
            val current = policy(tx.get(policyRef(uid)))
            val cutoff = current.cutoff()
            if (cutoff > maxOf(current.expiredBefore, current.clearedBefore)) {
                val next = current.copy(expiredBefore = cutoff, revision = current.revision + 1)
                tx.set(policyRef(uid), policyWire(next))
                next
            } else current
        }.await()
        cache(uid, p)
        val old = events(uid).whereLessThanOrEqualTo("occurredAt", p.cutoff()).limit(200).get(Source.SERVER).await()
        if (!old.isEmpty) firestore.batch().also { batch -> old.documents.forEach { batch.delete(it.reference) } }.commit().await()
    }
    fun schedule(uid: String) {
        val request = OneTimeWorkRequestBuilder<ActivitySyncWorker>()
            .setInputData(workDataOf("uid" to uid)).setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS).build()
        WorkManager.getInstance(context).enqueueUniqueWork("activity-sync-$uid", ExistingWorkPolicy.KEEP, request)
    }
}

class ActivitySyncWorker(context: Context, parameters: WorkerParameters) : CoroutineWorker(context, parameters) {
    override suspend fun doWork(): Result {
        val uid = inputData.getString("uid") ?: FirebaseAuth.getInstance().currentUser?.uid ?: return Result.success()
        if (FirebaseAuth.getInstance().currentUser?.uid != uid) return Result.success()
        return try { if ((applicationContext as DriveAlertApplication).container.activityRepository.synchronize(uid)) Result.success() else Result.retry() }
        catch (cancelled: CancellationException) { throw cancelled }
        catch (_: Exception) { Result.retry() }
    }
    companion object {
        fun schedulePeriodic(context: Context) {
            WorkManager.getInstance(context).enqueueUniquePeriodicWork("activity-retention", ExistingPeriodicWorkPolicy.KEEP,
                PeriodicWorkRequestBuilder<ActivitySyncWorker>(1, TimeUnit.HOURS).setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).build())
        }
    }
}
