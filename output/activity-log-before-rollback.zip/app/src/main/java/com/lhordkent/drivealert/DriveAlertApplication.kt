package com.lhordkent.drivealert

import android.app.Application
import com.lhordkent.drivealert.data.local.DriveAlertDatabase
import com.lhordkent.drivealert.data.repository.AlertRepository
import com.lhordkent.drivealert.data.repository.MonitoringSessionRepository
import com.lhordkent.drivealert.data.repository.RoomAlertRepository
import com.lhordkent.drivealert.data.repository.RoomMonitoringSessionRepository
import com.lhordkent.drivealert.data.repository.DriverPreferenceRepository
import com.lhordkent.drivealert.data.repository.RoomDriverPreferenceRepository
import com.lhordkent.drivealert.data.repository.CalibrationRepository
import com.lhordkent.drivealert.data.repository.RoomCalibrationRepository
import com.lhordkent.drivealert.data.repository.ProvisionedDeviceRepository
import com.lhordkent.drivealert.data.repository.RoomProvisionedDeviceRepository
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.firestore.PersistentCacheSettings
import com.lhordkent.drivealert.data.profile.FirestoreUserProfileRepository
import com.lhordkent.drivealert.data.profile.UserProfileRepository
import com.lhordkent.drivealert.data.connection.FirestoreTrustedContactRepository
import com.lhordkent.drivealert.data.connection.TrustedContactRepository
import com.lhordkent.drivealert.data.sync.FirestoreStageSyncRemoteDataSource
import com.lhordkent.drivealert.data.sync.RoomStageSyncRepository
import com.lhordkent.drivealert.data.sync.StageSyncProcessor
import com.lhordkent.drivealert.data.sync.StageSyncRemoteDataSource
import com.lhordkent.drivealert.data.sync.StageSyncRepository
import com.lhordkent.drivealert.data.sync.StageSyncScheduler
import com.lhordkent.drivealert.data.sync.WorkManagerStageSyncScheduler
import com.lhordkent.drivealert.data.sync.CloudflareStageNotificationRemoteDataSource
import com.lhordkent.drivealert.data.sync.StageNotificationDispatcher
import com.lhordkent.drivealert.data.sync.FirestoreSharedStage3Repository
import com.lhordkent.drivealert.data.sync.SharedStage3Repository
import com.lhordkent.drivealert.notification.AndroidDriverWarningNotificationGateway
import com.lhordkent.drivealert.notification.AndroidDriverVisibilityNotificationGateway
import com.lhordkent.drivealert.notification.DriverVisibilityNotificationCoordinator
import com.lhordkent.drivealert.notification.DriverWarningNotificationCoordinator
import com.lhordkent.drivealert.notification.DriveAlertMessagingService
import com.lhordkent.drivealert.notification.TrustedContactDeviceRegistrar
import com.lhordkent.drivealert.detection.DriverVisionRuntime
import com.lhordkent.drivealert.data.local.entity.MonitoringSessionStatus
import com.lhordkent.drivealert.monitoring.DriveAlertMonitoringService
import com.lhordkent.drivealert.monitoring.MonitoringRecoveryStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class DriveAlertApplication : Application() {
    val container: AppContainer by lazy { AppContainer(this) }

    override fun onCreate() {
        super.onCreate()
        AndroidDriverWarningNotificationGateway.createChannel(this)
        AndroidDriverVisibilityNotificationGateway.createChannel(this)
        DriveAlertMessagingService.createChannels(this)
        DriveAlertMonitoringService.createChannel(this)
        container.interruptRecoveryFromPreviousBoot()
        com.lhordkent.drivealert.data.history.HistoryCleanupWorker.schedule(this)
        com.lhordkent.drivealert.data.activity.ActivitySyncWorker.schedulePeriodic(this)
    }
}

class AppContainer(private val application: Application) {
    private val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    val database: DriveAlertDatabase = DriveAlertDatabase.getInstance(application)
    val firestore: FirebaseFirestore by lazy {
        FirebaseFirestore.getInstance().apply {
            firestoreSettings = FirebaseFirestoreSettings.Builder()
                .setLocalCacheSettings(PersistentCacheSettings.newBuilder().build())
                .build()
        }
    }
    val historyRepository = com.lhordkent.drivealert.data.history.HistoryRepository(database)
    val activityRepository by lazy { com.lhordkent.drivealert.data.activity.ActivityRepository(application, database.activityDao(), firestore) }
    val alertRepository: AlertRepository = RoomAlertRepository(database.alertDao())
    val driverWarningNotificationCoordinator = DriverWarningNotificationCoordinator(
        AndroidDriverWarningNotificationGateway(application),
    )
    val driverVisibilityNotificationCoordinator = DriverVisibilityNotificationCoordinator(
        AndroidDriverVisibilityNotificationGateway(application),
    )
    val trustedContactDeviceRegistrar = TrustedContactDeviceRegistrar(application)
    val monitoringSessionRepository: MonitoringSessionRepository =
        RoomMonitoringSessionRepository(database.monitoringSessionDao(), onSessionFinished = historyRepository::cleanup)
    val driverPreferenceRepository: DriverPreferenceRepository =
        RoomDriverPreferenceRepository(database.driverPreferenceDao())
    val calibrationRepository: CalibrationRepository = RoomCalibrationRepository(database.calibrationDao())
    val provisionedDeviceRepository: ProvisionedDeviceRepository =
        RoomProvisionedDeviceRepository(database.provisionedDeviceDao())
    val userProfileRepository: UserProfileRepository by lazy { FirestoreUserProfileRepository(firestore) }
    val trustedContactRepository: TrustedContactRepository by lazy {
        FirestoreTrustedContactRepository(
            firestore = firestore,
            projectionDao = database.trustedContactConnectionProjectionDao(),
        )
    }
    val stageSyncScheduler: StageSyncScheduler by lazy { WorkManagerStageSyncScheduler(application) }
    val stageSyncRemoteDataSource: StageSyncRemoteDataSource by lazy { FirestoreStageSyncRemoteDataSource(firestore) }
    val stageSyncProcessor: StageSyncProcessor by lazy {
        StageSyncProcessor(
            database.stageSyncRecordDao(),
            stageSyncRemoteDataSource,
            database.stageNotificationGroupDao(),
        )
    }
    val stageNotificationDispatcher: StageNotificationDispatcher by lazy {
        StageNotificationDispatcher(
            database.stageNotificationGroupDao(),
            CloudflareStageNotificationRemoteDataSource(),
        )
    }
    val stageSyncRepository: StageSyncRepository by lazy {
        RoomStageSyncRepository(database.stageSyncRecordDao(), stageSyncScheduler)
    }
    val sharedStage3Repository: SharedStage3Repository by lazy { FirestoreSharedStage3Repository(firestore) }
    val driverVisionRuntime: DriverVisionRuntime by lazy {
        DriverVisionRuntime(
            application = application,
            calibrationRepository = calibrationRepository,
            deviceRepository = provisionedDeviceRepository,
            monitoringSessionRepository = monitoringSessionRepository,
            alertRepository = alertRepository,
            stageSyncRepository = stageSyncRepository,
            notificationCoordinator = driverWarningNotificationCoordinator,
            visibilityNotificationCoordinator = driverVisibilityNotificationCoordinator,
            activityRepository = activityRepository,
        )
    }

    fun interruptRecoveryFromPreviousBoot() {
        val store = MonitoringRecoveryStore(application)
        val recovery = store.load() ?: return
        if (recovery.bootCount != MonitoringRecoveryStore.UNKNOWN_BOOT_COUNT &&
            recovery.bootCount == store.currentBootCount()
        ) return
        store.clear()
        applicationScope.launch {
            runCatching {
                monitoringSessionRepository.finish(
                    driverUserId = recovery.driverUserId,
                    sessionId = recovery.sessionId,
                    status = MonitoringSessionStatus.INTERRUPTED,
                    endedAtEpochMillis = System.currentTimeMillis(),
                )
            }
        }
    }
}
