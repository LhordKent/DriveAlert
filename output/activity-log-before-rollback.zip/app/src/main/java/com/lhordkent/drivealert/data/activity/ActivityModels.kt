package com.lhordkent.drivealert.data.activity

enum class ActivityAction(val category: String, val label: String) {
    SIGN_IN("ACCOUNT", "Signed in"), REGISTER("ACCOUNT", "Created an account"), LOGOUT("ACCOUNT", "Logged out"),
    PROFILE_SAVE("ACCOUNT", "Saved profile"), SCREEN_VIEW("NAVIGATION", "Opened"),
    DEVICE_CONNECT("DEVICE", "Connected device"), DEVICE_DISCONNECT("DEVICE", "Disconnected device"),
    DEVICE_SETUP("DEVICE", "Completed device setup"), CALIBRATION_START("DEVICE", "Started calibration"),
    CALIBRATION_COMPLETE("DEVICE", "Completed calibration"), CALIBRATION_CANCEL("DEVICE", "Cancelled calibration"),
    MONITORING_START("DEVICE", "Started monitoring"), MONITORING_STOP("DEVICE", "Stopped monitoring"),
    MONITORING_PAUSE("DEVICE", "Paused monitoring"), MONITORING_RESUME("DEVICE", "Resumed monitoring"),
    CONNECTION_SEND("CONNECTIONS", "Sent connection request"), CONNECTION_ACCEPT("CONNECTIONS", "Accepted connection request"),
    CONNECTION_DECLINE("CONNECTIONS", "Declined connection request"), CONNECTION_CANCEL("CONNECTIONS", "Cancelled connection request"),
    CONNECTION_REMOVE("CONNECTIONS", "Removed connection"), VIEW_CHANGE("SETTINGS", "Changed active view"),
    SOUND_CHANGE("SETTINGS", "Changed warning sound"), VOLUME_CHANGE("SETTINGS", "Changed warning volume"),
    NOTIFICATIONS_CHANGE("SETTINGS", "Changed notification preferences"), HISTORY_RETENTION("SETTINGS", "Changed alert-history retention"),
    HISTORY_DELETE("SETTINGS", "Deleted alert history"),
}

val activityScreens = mapOf(
    "dashboard" to "Dashboard", "drivers" to "Connected Drivers", "requests" to "Requests", "invite" to "Invite connection",
    "account" to "Account", "settings" to "Settings", "history" to "History & Storage", "about" to "About DriveAlert",
    "driver" to "Driver shared history", "record" to "Shared record details", "home" to "Home", "alerts" to "Alert History",
    "alert" to "Alert details", "contacts" to "Trusted Contacts", "setup" to "Setup & Device", "connection" to "Device connection",
    "alignment" to "Camera alignment", "calibration" to "Calibration", "monitoring" to "Monitoring", "notifications" to "Notifications",
    "sound" to "Warning Sound", "view" to "Choose view",
)
val activityCategories = linkedMapOf("ALL" to "All", "ACCOUNT" to "Account", "NAVIGATION" to "Navigation", "DEVICE" to "Device & Monitoring", "CONNECTIONS" to "Connections", "SETTINGS" to "Settings")
const val ACTIVITY_DAY = 86_400_000L
data class ActivityPolicy(val days: Int? = null, val expiredBefore: Long = 0, val clearedBefore: Long = 0, val revision: Long = 0) {
    fun cutoff(now: Long = System.currentTimeMillis()): Long = maxOf(expiredBefore, clearedBefore, days?.let { now - it * ACTIVITY_DAY } ?: 0)
}
fun validateActivityDays(days: Int?) { require(days == null || days in 1..3650) { "Enter 1 to 3,650 whole days." } }
fun ActivityEntry.description(): String {
    val title = ActivityAction.valueOf(action).label
    val description = if (action == "SCREEN_VIEW") "$title ${activityScreens[detail] ?: "screen"}" else title
    return description + when (outcome) { "FAILURE" -> " — failed"; "REQUESTED" -> " — requested"; else -> "" }
}
