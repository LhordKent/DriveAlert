package com.lhordkent.drivealert.data.activity

import androidx.compose.runtime.*
import androidx.lifecycle.*
import com.google.firebase.firestore.ListenerRegistration
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class ActivityLogViewModel(private val repository: ActivityRepository) : ViewModel() {
    val storageError = repository.storageError
    var policy by mutableStateOf(ActivityPolicy()); private set
    var entries by mutableStateOf(emptyList<ActivityEntry>()); private set
    var error by mutableStateOf<String?>(null); private set
    var message by mutableStateOf<String?>(null); private set
    var loading by mutableStateOf(true); private set
    var busy by mutableStateOf(false); private set
    var online by mutableStateOf(false); private set
    var hasMore by mutableStateOf(false); private set
    var preview by mutableStateOf<ActivityRepository.Preview?>(null); private set
    private var uid: String? = null
    private var count = 50L
    private var local = emptyList<ActivityEntry>()
    private var cloud = emptyList<ActivityEntry>()
    private var deleted = emptySet<String>()
    private var policyOnline = false
    private var cloudOnline = false
    private var localJob: Job? = null
    private var actionJob: Job? = null
    private var refreshJob: Job? = null
    private var cloudListener: ListenerRegistration? = null
    private val listeners = mutableListOf<ListenerRegistration>()
    fun bind(next: String?) {
        if (next == uid) return
        localJob?.cancel(); actionJob?.cancel(); refreshJob?.cancel(); cloudListener?.remove(); listeners.forEach { it.remove() }; listeners.clear()
        uid = next; count = 50; local = emptyList(); cloud = emptyList(); deleted = emptySet(); entries = emptyList()
        policy = ActivityPolicy(); error = null; message = null; preview = null; online = false; busy = false; loading = next != null
        policyOnline = false; cloudOnline = false
        if (next == null) return
        observeLocal(next)
        listeners += repository.observePolicy(next, { value, cached ->
            if (uid == next) { if (value.revision >= policy.revision) policy = value; policyOnline = !cached; update() }
        }, { if (uid == next) failed() })
        listeners += repository.observeDeletions(next, { value -> if (uid == next) { deleted = value; update() } }, { if (uid == next) failed() })
        listen(next)
        refresh()
    }
    private fun observeLocal(next: String) {
        localJob?.cancel()
        localJob = viewModelScope.launch {
            val cached = repository.cachedPolicy(next)
            if (cached.revision > policy.revision) policy = cached
            try { repository.observe(next, count.toInt()).collect { if (uid == next) { local = it; if (it.isNotEmpty()) loading = false; update() } } }
            catch (cancelled: CancellationException) { throw cancelled }
            catch (_: Exception) { if (uid == next) { error = "Local activity could not load. Reopen Activity Log to retry."; loading = false } }
        }
    }
    private fun failed() { error = "Activity could not synchronize. Connect to the internet and retry."; loading = false; online = false }
    private fun listen(owner: String) {
        cloudListener?.remove()
        cloudListener = repository.observeCloud(owner, count, { value, cached ->
            if (uid == owner) { cloud = value; cloudOnline = !cached; loading = false; hasMore = value.size >= count; update() }
        }, { if (uid == owner) failed() })
    }
    private fun update() {
        online = policyOnline && cloudOnline
        entries = (cloud + local).associateBy { it.eventId }.values
            .filter { it.occurredAt > policy.cutoff() && it.eventId !in deleted }
            .sortedWith(compareByDescending<ActivityEntry> { it.occurredAt }.thenByDescending { it.eventId }).take(count.toInt())
        hasMore = local.size >= count || cloud.size >= count
    }
    fun refresh() {
        val owner = uid ?: return
        repository.schedule(owner)
        update()
        error = null
        listen(owner)
        if (refreshJob?.isActive != true) refreshJob = viewModelScope.launch {
            try { repository.synchronize(owner) }
            catch (cancelled: CancellationException) { throw cancelled }
            catch (_: Exception) { if (uid == owner) { loading = false; error = "Activity could not synchronize. Connect to the internet and retry." } }
        }
    }
    fun loadMore() { val owner = uid ?: return; count += 50; observeLocal(owner); listen(owner) }
    fun dismissPreview() { if (!busy) { preview = null; error = null } }
    private fun action(operation: suspend (String) -> Unit) {
        val owner = uid ?: return
        if (busy) return
        busy = true; error = null; message = null
        actionJob = viewModelScope.launch {
            try { operation(owner) }
            catch (cancelled: CancellationException) { throw cancelled }
            catch (failure: Exception) { if (uid == owner) {
                error = if (failure is IllegalStateException) failure.message else "Change could not be confirmed. Connect to the internet and try again."
                if (failure is IllegalStateException) { preview = null; refreshPolicyAfterConflict(owner) }
            } }
            finally { if (uid == owner) busy = false }
        }
    }
    private fun refreshPolicyAfterConflict(owner: String) { viewModelScope.launch { runCatching { repository.refreshPolicy(owner) }.onSuccess { if (uid == owner) { policy = it; update() } } } }
    fun save(days: Int?) = action { owner ->
        validateActivityDays(days)
        if (days != null && (policy.days == null || days < policy.days!!)) preview = repository.preview(owner, days)
        else { repository.save(owner, days, policy.revision); policy = repository.refreshPolicy(owner); message = "Activity retention saved for your account."; update() }
    }
    fun confirmRetention() {
        val confirmed = preview ?: return
        action { owner ->
            repository.save(owner, confirmed.days, confirmed.revision, confirmed.cutoff)
            policy = repository.refreshPolicy(owner); preview = null; message = "Activity retention saved for your account."; update()
        }
    }
    fun remove(id: String) = action { owner ->
        repository.remove(owner, id); deleted = deleted + id; message = "Activity deleted from your account."; update()
    }
    fun clear() = action { owner ->
        repository.clear(owner); policy = repository.refreshPolicy(owner); message = "Activity cleared from your account."; update()
    }
    override fun onCleared() { cloudListener?.remove(); listeners.forEach { it.remove() } }
}
class ActivityLogViewModelFactory(private val repository: ActivityRepository) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST") override fun <T : ViewModel> create(modelClass: Class<T>): T = ActivityLogViewModel(repository) as T
}
