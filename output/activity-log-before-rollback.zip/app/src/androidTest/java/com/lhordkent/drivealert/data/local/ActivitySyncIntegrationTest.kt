package com.lhordkent.drivealert.data.local

import androidx.room.Room
import androidx.test.platform.app.InstrumentationRegistry
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.*
import com.lhordkent.drivealert.DriveAlertApplication
import com.lhordkent.drivealert.data.activity.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.tasks.await
import org.junit.*
import org.junit.Assert.*

/** Requires Auth 9099 and Firestore 8188 emulators on the host. Never uses production. */
class ActivitySyncIntegrationTest {
    private lateinit var db: DriveAlertDatabase
    private lateinit var repository: ActivityRepository
    private lateinit var firestore: FirebaseFirestore
    private lateinit var uid: String
    @Before fun setup() = runBlocking {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val auth = FirebaseAuth.getInstance()
        firestore = (context.applicationContext as DriveAlertApplication).container.firestore
        if (!configured) {
            auth.useEmulator("10.0.2.2", 9099)
            firestore.useEmulator("10.0.2.2", 8188)
            configured = true
        }
        uid = auth.createUserWithEmailAndPassword("native-${System.nanoTime()}@example.com", "Password123!").await().user!!.uid
        db = Room.inMemoryDatabaseBuilder(context, DriveAlertDatabase::class.java).build()
        repository = ActivityRepository(context, db.activityDao(), firestore)
    }
    @After fun close() { FirebaseAuth.getInstance().signOut(); db.close() }
    private fun events() = firestore.collection("users").document(uid).collection("activityLogs")
    private fun entry(id: String, at: Long = System.currentTimeMillis()) = ActivityEntry(uid, id, at, "ANDROID", "DRIVER", "ACCOUNT", "SIGN_IN", "SUCCESS")
    @Test fun androidUploadWebContractAndDeletionPreventRecreation() = runBlocking {
        val original = entry("android")
        db.activityDao().insert(original)
        repository.synchronize(uid)
        repository.synchronize(uid)
        assertEquals(1, events().get(Source.SERVER).await().size())
        assertEquals("ANDROID", events().document("android").get(Source.SERVER).await().getString("platform"))
        events().document("web").set(mapOf("eventId" to "web", "schemaVersion" to 1, "occurredAt" to System.currentTimeMillis(), "platform" to "WEB", "activeView" to "TRUSTED_CONTACT", "category" to "ACCOUNT", "action" to "SIGN_IN", "outcome" to "SUCCESS", "detail" to "", "operationId" to "", "receivedAt" to FieldValue.serverTimestamp())).await()
        assertEquals("WEB", repository.decode(uid, events().document("web").get(Source.SERVER).await())?.platform)
        repository.remove(uid, "android")
        db.activityDao().insert(original) // A second offline device still has this event.
        repository.synchronize(uid)
        assertFalse(events().document("android").get(Source.SERVER).await().exists())
        assertTrue(db.activityDao().pending(uid).isEmpty())
        // Deleting an event which has never uploaded must also succeed.
        repository.remove(uid, "pending-only")
        db.activityDao().insert(entry("pending-only"))
        repository.synchronize(uid)
        assertFalse(events().document("pending-only").get(Source.SERVER).await().exists())
    }
    @Test fun retentionClearAndOfflineEntriesFollowAccountPolicy() = runBlocking {
        val old = entry("old", System.currentTimeMillis() - 2 * ACTIVITY_DAY)
        db.activityDao().insert(old); db.activityDao().insert(entry("recent"))
        repository.synchronize(uid)
        val preview = repository.preview(uid, 1)
        assertEquals(1, preview.count)
        repository.save(uid, 1, preview.revision, preview.cutoff)
        repository.synchronize(uid)
        assertFalse(events().document("old").get(Source.SERVER).await().exists())
        val current = repository.refreshPolicy(uid)
        repository.save(uid, null, current.revision)
        db.activityDao().insert(old)
        repository.synchronize(uid)
        assertFalse(events().document("old").get(Source.SERVER).await().exists())
        val delayed = entry("delayed", System.currentTimeMillis() - 1000)
        repository.clear(uid)
        db.activityDao().insert(delayed)
        repository.synchronize(uid)
        assertTrue(events().get(Source.SERVER).await().isEmpty)
        delay(10)
        db.activityDao().insert(entry("new"))
        repository.synchronize(uid)
        assertEquals(1, events().get(Source.SERVER).await().size())
    }
    companion object { private var configured = false }
}
