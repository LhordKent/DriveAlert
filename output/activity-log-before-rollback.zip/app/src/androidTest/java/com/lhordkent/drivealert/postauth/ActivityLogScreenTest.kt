package com.lhordkent.drivealert.postauth

import android.graphics.Bitmap
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.unit.Density
import androidx.room.Room
import androidx.test.platform.app.InstrumentationRegistry
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.firestore.FirebaseFirestore
import com.lhordkent.drivealert.data.activity.*
import com.lhordkent.drivealert.data.local.DriveAlertDatabase
import com.lhordkent.drivealert.ui.postauth.ActivityLogScreen
import com.lhordkent.drivealert.ui.postauth.ActivityRetentionScreen
import com.lhordkent.drivealert.ui.theme.DriveAlertTheme
import kotlinx.coroutines.runBlocking
import org.junit.*
import java.io.File

class ActivityLogScreenTest {
    @get:Rule val compose = createComposeRule()
    private lateinit var db: DriveAlertDatabase
    private lateinit var model: ActivityLogViewModel
    private lateinit var firebase: FirebaseApp
    @Before fun setup() = runBlocking {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        db = Room.inMemoryDatabaseBuilder(context, DriveAlertDatabase::class.java).build()
        firebase = FirebaseApp.initializeApp(context, FirebaseOptions.Builder().setProjectId("demo-activity-ui").setApplicationId("activity-ui").setApiKey("demo-key").build(), "activity-ui-${System.nanoTime()}")
        val firestore = FirebaseFirestore.getInstance(firebase)
        firestore.useEmulator("10.0.2.2", 8188)
        firestore.disableNetwork()
        db.activityDao().insert(ActivityEntry("ui-test", "local-test", System.currentTimeMillis(), "ANDROID", "DRIVER", "DEVICE", "MONITORING_START", "SUCCESS"))
        model = ActivityLogViewModel(ActivityRepository(context, db.activityDao(), firestore))
        compose.runOnIdle { model.bind("ui-test") }
    }
    @After fun close() { compose.runOnIdle { model.bind(null) }; db.close(); firebase.delete() }
    @Test fun timelineShowsOfflineActivityAndDisablesAccountDeletion() {
        compose.setContent { DriveAlertTheme { CompositionLocalProvider(LocalDensity provides Density(LocalDensity.current.density, 1.3f)) {
            ActivityLogScreen(model, {}, {})
        } } }
        compose.onNodeWithText("Started monitoring").performScrollTo().assertIsDisplayed()
        compose.onNodeWithText("Delete activity").assertIsNotEnabled()
        compose.onNodeWithText("Clear all activity").performScrollTo().assertIsNotEnabled()
        capture("activity-android.png")
    }
    @Test fun retentionOffersExistingDurationsAndExplainsOfflineChanges() {
        compose.setContent { DriveAlertTheme { ActivityRetentionScreen(model, {}) } }
        listOf("1 day", "3 days", "7 days", "Custom", "Keep until I delete").forEach { compose.onNodeWithText(it).performScrollTo().assertExists() }
        compose.onNodeWithText("Save", useUnmergedTree = true).performScrollTo().assertExists()
        capture("activity-android-retention.png")
    }
    private fun capture(name: String) {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        File(context.cacheDir, name).outputStream().use { compose.onRoot().captureToImage().asAndroidBitmap().compress(Bitmap.CompressFormat.PNG, 100, it) }
    }
}
