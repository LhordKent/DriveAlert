package com.lhordkent.drivealert.data.local

import androidx.room.Room
import androidx.test.platform.app.InstrumentationRegistry
import com.lhordkent.drivealert.data.activity.*
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.*
import org.junit.Assert.*

class ActivityDaoTest {
    private lateinit var db: DriveAlertDatabase
    @Before fun setup() { db = Room.inMemoryDatabaseBuilder(InstrumentationRegistry.getInstrumentation().targetContext, DriveAlertDatabase::class.java).build() }
    @After fun close() = db.close()
    @Test fun accountIsolationRetriesExpiryAndUploadState() = runBlocking {
        val dao = db.activityDao()
        val entry = ActivityEntry("a", "same-id", 100, "ANDROID", "DRIVER", "ACCOUNT", "SIGN_IN", "SUCCESS")
        dao.insert(entry); dao.insert(entry); dao.insert(entry.copy(uid = "b"))
        assertEquals(1, dao.pending("a").size)
        dao.uploaded("a", entry.eventId)
        assertTrue(dao.pending("a").isEmpty())
        assertTrue(dao.observe("a").first().isNotEmpty())
        dao.expire("a", 100)
        assertTrue(dao.observe("a").first().isEmpty())
        assertEquals(1, dao.pending("b").size)
        dao.remove("a", "same-id")
        assertEquals(1, dao.observe("b").first().size)
    }
}
